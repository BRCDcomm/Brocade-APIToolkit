# Copyright (c) 2014, Brocade Communications Systems, Inc.
#
# All rights reserved.
#
# This software is licensed under the following BSD-license,
# you may not use this file unless in compliance with the
# license below:
#
# Redistribution and use in source and binary forms, with or
# without modification, are permitted provided that the
# following conditions are met:
#
# 1. Redistributions of source code must retain the above
#    copyright notice, this list of conditions and the
#    following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
# THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
# THE POSSIBILITY OF SUCH DAMAGE.


from http import client
from urllib import parse
from urllib.request import Request, urlopen


from utilities import http_utils
from utilities import parser
from scripts.inventory import DeviceInventory

from scripts import payload as PF


class VlanConfig:
    '''
    '''

    def __init__(self, connector):
        self._connector = connector

    def create_vlan(self, name):
        ''' Create VLAN
        '''
        assert name != '', "Empty VLAN name is not allowed"

        # Create Request header dictionary
        headers = http_utils.http_post_request_headers()

        # build URL to create a new vlan
        url = self._connector.get_config_url()
        url += "/interface/"
        
        print(url)

        # build payload
        payload = PF.create_vlan_payload(name)

        print(payload)
        # build request object with URL and headers
        req = Request(url, payload, headers, method="POST")

        response = urlopen(req)
        response.close()

        if response.getcode() != client.CREATED:
            raise Exception("Failed to create VLAN" + name)

    def delete_vlan(self, name=''):
        ''' Removes a  VLAN
        '''
        assert name != '', "Empty VLAN name is not allowed"

        # Create Request header dictionary
        headers = http_utils.http_post_request_headers()

        #build URL to create a new vlan
        url = self._connector.get_config_url()
        url += "/interface/vlan/" + name

        # build request object with URL and headers
        req = Request(url, None, headers, method="DELETE")

        response = urlopen(req)
        response.close()

        if response.getcode() != client.NO_CONTENT:
            raise Exception("Failed to remove VLAN " + name)

    def add_interfaces_to_vlan(self, interfaces, vlan, mode="trunk"):
        ''' Add a list of interfaces to a vlan.
            interfaces is a list of physical or logical interfaces.
            vlan is id of the vlan without VLAN prefix.
            vlan_mode is 'trunk' or 'access'. Default is 'trunk'
        '''
        assert interfaces != [], "Empty list of interfaces is not allowed"

        # Add VLAN to the device if it doesn't exit.
        if not self.has_vlan(vlan):
            print("VLAN " + vlan + " not found!. Creating it.")
            self.create_vlan(vlan)

        # Create Request header dictionary
        headers = http_utils.http_post_request_headers()

        # Build patch commands to add vlan
        # Adding VLAN to each interface
        print("Configuring VLAN " + vlan + " on interfaces:")
        for interface in interfaces:
            print("\tInterface: " + interface)
            # set interface to switchport mode.
            # build request to patch interface details.
            interface_details = str(interface).split(sep=" ")
            interface_type = interface_details[0]
            name = interface_details[1]

            di = DeviceInventory(self._connector)
            int_dom = di.get_interface(name, interface_type)
            # is port in switchport mode?
            switch_port_elems = int_dom.getElementsByTagName(PF.SWITCHPORT_TAG)
            interface_type = interface_type.lower()

            # build interface update URL
            url = self._connector.get_config_url() + "/interface/"
            url += interface_type + "/"
            url += parse.quote('"' + name + '"')

            is_switchport = parser.get_Element_data(switch_port_elems[0])
            if is_switchport != "true":
                # configure the port as switch port
                print("\t\tConfigure the interface as switch port")
                byteData = PF.interface_switchport_payload(interface_type)

                req = Request(url, byteData, headers, method="PATCH")

                response = urlopen(req)
                response.close()

                if response.getcode() != client.NO_CONTENT:
                    msg = "Failed to configure switchport on interface: " + \
                                interface
                    raise Exception(msg)

            # configure the interface mode
            print("\t\tConfiguring " + mode +
                  " mode on interface")
            byteData = PF.interface_vlan_mode_payload(interface_type, mode)
            req = Request(url, byteData, headers, method="PATCH")
            response = urlopen(req)
            response.close()

            if response.getcode() != client.NO_CONTENT:
                raise Exception("Failed to configure mode" + mode +
                                " on interface: " + interface)

            # add interface to vlan
            print("\t\tAdding VLAN " + vlan +
                  " on interface: " + interface)
            byteData = PF.interface_allowed_vlan_payload(interface_type,
                                                         mode, vlan)
            #print ("\t Payload: " + str(byteData))
            #print(url)
            req = Request(url, byteData, headers, method="PATCH")
            response = urlopen(req)
            response.close()

            if response.getcode() != client.NO_CONTENT:
                raise Exception("Failed to add VLAN " +
                                vlan + " on interface: " + interface)

    def remove_interfaces_from_vlan(self, name, interfaces):
        ''' Removes interfaces from VLAN.
            name is id of the VLAN
            interfaces a list of Ports and LAGs
        '''
        assert name != None, "VLAN name can't be None"
        assert interfaces != [], "Empty list of interfaces is not allowed"

        if not self.has_vlan(name):
            raise Exception("VLAN " + name + " not exist!")

        # Create Request header dictionary
        headers = http_utils.http_post_request_headers()

        print("Removing interfaces from VLAN " + name + ":")
        for interface in interfaces:
            print("\tRemoving interface: " + interface)
            interface_details = str(interface).split(sep=" ")
            interface_type = interface_details[0]
            interface_name = interface_details[1]

            # get interface details to identify current vlan-mode
            di = DeviceInventory(self._connector)
            int_elm = di.get_interface(interface_name,
                                                   interface_type)
            vlan_mode_elms = int_elm.getElementsByTagName(PF.VLAN_MODE_TAG)
            vlan_mode = None
            if vlan_mode_elms != None:
                vlan_mode_elm = vlan_mode_elms[0]
                vlan_mode = parser.get_Element_data(vlan_mode_elm)
                #print (vlan_mode)

            if vlan_mode == None:
                continue
            elif vlan_mode == PF.VLAN_MODE_ACCESS:
                url = self._connector.get_config_url() + "/interface/"
                url += interface_type + "/"
                url += parse.quote('"' + interface_name.lower() + '"') + "/"
                url += PF.SWITCHPORT_TAG
                #print("\t Request URL: " + url)

                req = Request(url, None, headers, method="DELETE")
                response = urlopen(req)
                response.close()

                if response.getcode() != client.NO_CONTENT:
                    raise Exception("Failed to remove " +
                                    vlan_mode + " mode VLAN " + name
                                    + " on interface: " + interface)
            elif vlan_mode == PF.VLAN_MODE_TRUNK:
                url = self._connector.get_config_url() + "/interface/"
                url += interface_type + "/"
                url += parse.quote('"' + interface_name.lower() + '"')
                #print("\t Request URL: " + url)

                byteData = PF.interface_trunk_remove_vlan_payload(interface_type,
                                                           vlan_mode,
                                                           name)
                #print(byteData)

                req = Request(url, byteData, headers, method="PATCH")
                response = urlopen(req)
                response.close()

                if response.getcode() != client.NO_CONTENT:
                    raise Exception("Failed to remove " +
                                    vlan_mode + " mode VLAN " + name
                                    + " on interface: " + interface)

    def has_vlan(self, name):
        ''' Returns boolean True if the vlan exist on the device.
        '''
        found = False
        try:
            di = DeviceInventory(self._connector)
            vlan = di.get_vlan(name)
            if vlan != None:
                found = True

        except Exception as ex:
            print(str(ex))

        return found


if __name__ == '__main__':
    pass
