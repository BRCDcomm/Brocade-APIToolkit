# Copyright (c) 2014, Brocade Communications Systems, Inc.
#
# All rights reserved.
#
# This software is licensed under the following BSD-license,
# you may not use this file unless in compliance with the
# license below:
#
# Redistribution and use in source and binary forms, with or
# without modification, are permitted provided that the
# following conditions are met:
#
# 1. Redistributions of source code must retain the above
#    copyright notice, this list of conditions and the
#    following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
# THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
# THE POSSIBILITY OF SUCH DAMAGE.

from urllib.request import Request, urlopen
from xml.dom.minidom import parseString


from scripts import payload as PF
from utilities import http_utils, parser


class VrfConfig:

    def __init__(self, connector, config_type=http_utils.RUNNING):
        self._connector = connector
        self._config_type = config_type

    def create_vrf(self, rbridge_id, name, rd, address_family):
        '''
        create VRF and assign rd and address family
        '''
        # Create Request header dictionary
        headers = http_utils.http_post_request_headers()
        # build URL to rbridge id url
        url = self.get_rbridge_id_url(rbridge_id)
        # creating VRF and RD
        payload = PF.create_vrf_payload(name, rd)
        # build request object with URL and headers
        req = Request(url, payload, headers, method=http_utils.POST)
        response = urlopen(req)
        response.close()
        # setting address family
        address_payload = PF.add_vrf_address_family_payload(
            name, address_family)
        req = Request(url, address_payload, headers, method=http_utils.POST)
        response = urlopen(req)
        response.close()

    def get_vrf_details(self, rbridge_id, name):
        '''
         Fetch the VRF details for given vrf name
         '''
        # Create Request header dictionary
        headers = http_utils.http_get_request_headers(resource_depth=2)
        # build URL to vrf
        url = self.get_rbridge_id_url(rbridge_id) + "/vrf/"
        if name is not None:
            url += name

        # build request object with URL and headers
        req = Request(url, None, headers)
        response = urlopen(req)
        # read response data and decode the bytes in
        # a string and wrap into a an xml tag to build a dom
        data = response.read()
        strData = parser.decode_and_wrap_in_xml(data)
        response.close()
        return strData

    def list_configured_vrf(self, rbridge_id):
        '''
        Returns the a list of vrf XML DOM objects
        '''
        vrf_list = self.get_vrf_details(rbridge_id, None)
        # Create document object with response xml.
        dom = parseString(vrf_list)
        vrf_names_list = dom.getElementsByTagName("vrf-name")
        return vrf_names_list

    def configure_vrf_route_ip(self, rbridge_id, name, ipaddress):
        '''
        Configure the vrf route ip address to specific interface
        '''
        # Create Request header dictionary
        headers = http_utils.http_post_request_headers()
        # build URL to rbridge
        url = self.get_rbridge_id_url(rbridge_id)

        payload = PF.create_vrf_router_id_payload(name, ipaddress)
        # build request object with URL and headers
        req = Request(url, payload, headers, method=http_utils.POST)
        response = urlopen(req)
        response.close()

    def configure_vrf_forwarding(self, rbridge_id, name, interface_name):
        '''
        Configure VRF management interface/port
        '''
        interface_details = str(interface_name).split(sep=" ")
        interface_type = interface_details[0]
        interface_port = interface_details[1]
        # Create Request header dictionary
        headers = http_utils.http_post_request_headers()
        # build URL to interface
        url = self.get_rbridge_id_url(rbridge_id) + "/interface/" + interface_type + "/" + \
            + interface_port

        payload = PF.create_vrf_forwarding_payload(name)
        # build request object with URL and headers
        req = Request(url, payload, headers, method=http_utils.POST)
        response = urlopen(req)
        response.close()

    def get_rbridge_id_url(self, rbridge_id):
        url = self._connector.get_config_url(self._config_type)
        url += "/rbridge-id/" + str(rbridge_id)
        return url

    def delete_vrf(self, rbridge_id, name):
        '''
        Delete the VRF in the specified Rbridge
        '''
        # Create Request header dictionary
        headers = http_utils.http_post_request_headers()
        # build URL to rbridge id url
        url = self.get_rbridge_id_url(rbridge_id)
        url += "/vrf/" + name
        req = Request(url, None, headers, method=http_utils.DELETE)
        response = urlopen(req)
        response.close()
