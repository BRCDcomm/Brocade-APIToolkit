# Copyright (c) 2014, Brocade Communications Systems, Inc.
#
# All rights reserved.
#
# This software is licensed under the following BSD-license,
# you may not use this file unless in compliance with the
# license below:
#
# Redistribution and use in source and binary forms, with or
# without modification, are permitted provided that the
# following conditions are met:
#
# 1. Redistributions of source code must retain the above
#    copyright notice, this list of conditions and the
#    following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
# THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
# THE POSSIBILITY OF SUCH DAMAGE.

import ipaddress
import socket
import urllib
from urllib.request import HTTPPasswordMgrWithDefaultRealm
from urllib.request import HTTPBasicAuthHandler


class DeviceConnector:
    '''
    '''

    def __init__(self, ip_address, username, password,
                 scheme="http", http_port=80):
        '''
        '''
        self._ip_address = ipaddress.ip_address(ip_address)
        self._username = username
        self._password = password
        self._scheme = scheme
        self._http_port = http_port
        self._top_level_url = self._get_top_level_url(ip_address,
                                                      scheme, http_port)
        self._opener = self._build_default_opener()
        # Install the opener.
        # Now all calls to urllib.request.urlopen use
        # this installed opener.
        urllib.request.install_opener(self._opener)

    def _get_top_level_url(self, ip_address, scheme,
                           http_port, top_path='/rest'):
        '''
        '''
        top_url = scheme + "://" + ip_address
        if http_port != 80:
            top_url += ":" + http_port

        forward_separator = ""
        if top_path[0] != "/":
            forward_separator = "/"

        top_url = top_url + forward_separator + top_path

        return top_url

    def get_top_level_url(self):
        '''
        '''
        return self._top_level_url

    def get_ip_address(self):
        '''
        '''
        return self._ip_address

    def _build_default_opener(self):
        '''
        '''
        # create a password manager
        password_mgr = HTTPPasswordMgrWithDefaultRealm()

        # Add the username and password.
        password_mgr.add_password(None, self._top_level_url,
                                  self._username, self._password)
        authHandler = HTTPBasicAuthHandler(password_mgr)

        # create "opener" (OpenerDirector instance)
        opener = urllib.request.build_opener(authHandler)
        return opener

    def open(self, fullurl, data, timeout=socket._GLOBAL_DEFAULT_TIMEOUT):
        self._opener.open(fullurl, data, timeout)

    def get_config_url(self, config_type="running"):
        '''Returns a running or startup config url for the device
           config_type = running or startup
        '''
        url = self.get_top_level_url()
        url += "/config/" + config_type
        return url

    def get_operational_state_url(self):
        return self.get_top_level_url() + "/operational-state/"

   

if __name__ == '__main__':
    pass
