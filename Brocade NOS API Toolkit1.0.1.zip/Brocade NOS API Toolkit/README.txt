
Change Log:

2014 - Dec - 03
---------------

- Fixed defect 'Failed to remove VLAN id from an interface in trunk mode'


2014 - Oct - 8
--------------

-	The zip file name is changed from  NOS API Toolkit 1.0.zip to Brocade NOS API Toolkit 1.0.zip
-	The Brocade_API_Toolkit_Developer_Guide.docx is replaced with Brocade_API_Toolkit_Developer_Guide.pdf


2014 - Sep - 25
---------------

- Added vrf.py file to bin directory to configure VRF from commandline.
- Added vrfconfig.py file to scripts directory to manage vrf configuration on the device using REST APIs.
- Updated Brocade_API_Toolkit_Developer_Guide.docx with VRF configuration details as well VRF commandline help.


