# Copyright (c) 2014, Brocade Communications Systems, Inc.
#
# All rights reserved.
#
# This software is licensed under the following BSD-license,
# you may not use this file unless in compliance with the
# license below:
#
# Redistribution and use in source and binary forms, with or
# without modification, are permitted provided that the
# following conditions are met:
#
# 1. Redistributions of source code must retain the above
#    copyright notice, this list of conditions and the
#    following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
# THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
# THE POSSIBILITY OF SUCH DAMAGE.


import http
from urllib.request import Request, urlopen
from xml.dom.minidom import parseString

from scripts import payload as PF
from utilities import http_utils, parser
# Protocol Constants
PROTOCOL_VRRP = "vrrp"
PROTOCOL_VRRP_EXTENDED = "vrrp-extended"


class VrrpConfig:

    '''
    '''

    def __init__(self, connector, config_type=http_utils.RUNNING):
        self._connector = connector
        self._config_type = config_type

    def configure(self, rbridge_id, vrrp_group_id, interface,
                  interface_ip, interface_ip_mask, virtual_router_ipaddress,
                  protocol):
        ''' Configure VRRP/VRRP-E on the switch.
        '''
        print("Configuring VRRP protocol, interface IP, virtual VRRP" +
              "Group on interface and virtual IP on group...")

        interface_details = str(interface).split(sep=" ")
        interface_type = interface_details[0]
        interface_name = interface_details[1]
        # param validation
        if protocol == PROTOCOL_VRRP_EXTENDED:
            if interface_type not in "ve":
                raise Exception("VRRP-E virtual routers can be configured" +
                                " on Ve interfaces only")
        self.enable_vrrp_protocol(rbridge_id, protocol,  enable="true")

        self.add_interface_address(rbridge_id, protocol, interface_type,
                                   interface_name, interface_ip,
                                   interface_ip_mask)

        self.create_vrrp_group(rbridge_id, protocol, interface_type,
                               interface_name, vrrp_group_id)

        self.configure_virtual_ipaddress(rbridge_id, protocol,
                                         interface_type,
                                         interface_name,
                                         vrrp_group_id,
                                         virtual_router_ipaddress)

    def enable_vrrp_protocol(self, rbridge_id, protocol,  enable="true"):
        '''
        enabling/ disabling the Vrrp/Vrrp-e protocol
        '''
        print("Enable/Disable VRRP Protocol: " + enable)

        # Create Request header dictionary
        headers = http_utils.http_post_request_headers()

        # build URL to VRRP protocol
        url = self. get_vrrp_protocol_enable_url(rbridge_id)
        if enable == "true":
            # create VRRP protocol Enable request
            enble_payload = PF.vrrp_protocol_enable(protocol, enable)

            print("\tURL: " + url)
            print("\tPayload: " + str(enble_payload))

            req = Request(url, enble_payload, headers, method=http_utils.POST)
        else:
            url += "/" + protocol
            print("\tURL: " + url)
            req = Request(url, None, headers, method=http_utils.DELETE)

        # build request object with URL and headers
        try:
            response = urlopen(req)
            response.close()
        except Exception as ex:

            if ex.code == http.client.CONFLICT:
                pass  # already VRRP protocol is enabled
            else:
                raise Exception(
                    "Failed to enable/disable protocol " + protocol + ":"
                    + str(ex))

    def add_interface_address(self, rbridge_id, protocol, intrface_type,
                              interface_name, interface_ip, interface_ip_mask):
        ''' Adding interface ip '''

        print("Configure Interface IP...")

        # Create Request header dictionary
        headers = http_utils.http_post_request_headers()

        # build URL to create a new vrrp group
        url = self.get_vrrp_interface_url(
            rbridge_id, intrface_type, interface_name)
        url += "/ip"
        try:
            interface_address_payload = PF.vrrp_interface_ip_config_payload(
                interface_ip, interface_ip_mask)
            # print(interface_address_payload)

            print("\tURL: " + url)
            print("\tPayload: " + str(interface_address_payload))

            # build request object with URL and headers
            req = Request(
                url, interface_address_payload, headers,
                method=http_utils.POST)
            response = urlopen(req)
            response.close()
        except Exception as ex:
            if ex.code == http.client.CONFLICT:
                print("Interface is already configured " +
                      "with IP address")
            else:
                raise Exception("Failed to create interface IP address "
                                + interface_ip + ":" + str(ex))

    def create_vrrp_group(self, rbridge_id, protocol, interface_type,
                          interface_name, vrrp_group_id):
        ''' create VRRP group  '''

        print("Creating VRRP Group: " + str(vrrp_group_id))

        # Create Request header dictionary
        headers = http_utils.http_post_request_headers()
        url = self.get_vrrp_interface_url(rbridge_id,
                                          interface_type, interface_name)

        grp_payload = PF.vrrp_grp_config_payload(vrrp_group_id, protocol)

        # build request object with URL and headers
        try:
            print("\tURL: " + url)
            print("\tPayload: " + str(grp_payload))
            req = Request(url, grp_payload, headers, method=http_utils.POST)
            response = urlopen(req)
            response.close()
        except Exception as ex:
            self.delete_interface_ipaddress(
                rbridge_id, interface_type, interface_name)
            raise Exception("Failed to create VRRP group" + str(vrrp_group_id)
                            + ":" + str(ex))

    def configure_virtual_ipaddress(self, rbridge_id, protocol, intrface_type,
                                    interface_name, vrrp_group_id, virtual_ip):
        ''' Configure virtual router IP Address '''

        print("Configuring virtual IP Address...")

        # Create Request header dictionary
        headers = http_utils.http_post_request_headers()
        try:
            url = self.get_vrrp_interface_url(rbridge_id,
                                              intrface_type, interface_name)
            if protocol == PROTOCOL_VRRP:
                url += "/vrrp-group/" + str(vrrp_group_id) + "%2C2"
            else:
                url += "/vrrp-extended-group/" + str(vrrp_group_id)
            payload = PF.vrrp_virtual_ip_config_payload(virtual_ip)

            print("\tURL: " + url)
            print("\tPayload: " + str(payload))

            req = Request(url, payload, headers, method=http_utils.POST)
            response = urlopen(req)
            response.close()
        except Exception as ex:
            self.delete_interface_ipaddress(
                rbridge_id, intrface_type, interface_name)
            raise Exception(
                "Failed to assign virtual router IP Address " + str(ex))

    def preemption(self, rbridge_id, protocol, interface_link, vrrp_group_id,
                   enable):
        '''
        To enable preemption for a virtual router
        '''

        print("Enable/Disable Preemption: " + enable)

        interface_details = str(interface_link).split(sep=" ")
        interface_type = interface_details[0]
        interface_name = interface_details[1]

        headers = http_utils.http_post_request_headers()
        try:
            url = self.get_vrrp_interface_url(rbridge_id,
                                              interface_type, interface_name)
            if protocol == PROTOCOL_VRRP:
                url += "/vrrp-group/" + str(vrrp_group_id) + "%2c2"
            else:
                url += "/vrrp-extended-group/" + str(vrrp_group_id)

            url += "/preempt-mode"

            print("\tURL: " + url)

            if enable == "true":
                req = Request(url, None, headers, method=http_utils.PATCH)
            else:
                req = Request(url, None, headers, method=http_utils.DELETE)

            response = urlopen(req)
            response.close()
        except Exception as ex:
            raise Exception("Failed to enable/disable preemption mode "
                            + str(ex))

    def priority(self, rbridge_id, interface_link,
                 vrrp_group_id, priority, protocol=PROTOCOL_VRRP):
        '''
        '''
        print("Setting VRRP Group Priority...")
        if priority is None or int(priority) < 0 or int(priority) > 100:
            raise ValueError("Invalid priority")
        if interface_link is None:
            raise ValueError("interface can't be None")

        headers = http_utils.http_get_request_headers(5)
        interface_details = str(interface_link).split(sep=" ")
        interface_type = interface_details[0]
        interface_name = interface_details[1]

        if protocol == PROTOCOL_VRRP:
            url = self.get_vrrp_interface_track_url(
                rbridge_id, interface_type, interface_name, vrrp_group_id)
        else:
            url = self.get_vrrpe_interface_track_url(
                rbridge_id, interface_type, interface_name, vrrp_group_id)

        print("\ttrack url:" + url)
        req = Request(url, None, headers)
        response = urlopen(req)
        data = response.read()
        strData = parser.decode_and_wrap_in_xml(data)
        response.close()

        # parse the xml downloaded
        dom = parseString(strData)

        track_interface_type = dom.getElementsByTagName("interface-type")
        if track_interface_type.length == 0:
            raise ValueError("Track ports is not configured yet")

        str_track_int_type = track_interface_type[0].firstChild.nodeValue
        track_interface_name = dom.getElementsByTagName("interface-name")
        str_track_int_name = track_interface_name[0].firstChild.nodeValue
        headers = http_utils.http_post_request_headers()
        if protocol == PROTOCOL_VRRP:
            url = self.get_vrrp_trackport_priority_url(rbridge_id,
                                                       interface_type,
                                                       interface_name,
                                                       vrrp_group_id,
                                                       str_track_int_type,
                                                       str_track_int_name)
        else:
            url = self.get_vrrpe_trackport_priority_url(rbridge_id,
                                                        interface_type,
                                                        interface_name,
                                                        vrrp_group_id,
                                                        str_track_int_type,
                                                        str_track_int_name)
        payload = PF.vrrp_priority_payload(str(priority))

        print("\tURL: " + url)
        print("\tPayload: " + str(payload))

        req = Request(url, payload, headers, method=http_utils.PATCH)

        response = urlopen(req)
        response.close()

    def track_port(self, rbridge_id, interface_link, vrrp_group_id, track_port,
                   priority, protocol):
        '''
        A track port allows to monitor the state of the interfaces on
        the other end of a the route path.
        '''
        print("Configuring Port Tracking...")

        if priority is None or int(priority) < 0 or int(priority) > 100:
            raise ValueError("Invalid priority")
        if interface_link is None:
            raise ValueError("interface can't be None")
        if track_port is None:
            raise ValueError("track port interface can not be None")
        interface_details = str(interface_link).split(sep=" ")
        interface_type = interface_details[0]
        interface_name = interface_details[1]
        headers = http_utils.http_post_request_headers()
        if protocol == PROTOCOL_VRRP:
            url = self.get_vrrp_interface_track_url(rbridge_id, interface_type,
                                                    interface_name,
                                                    vrrp_group_id)
        else:
            url = self.get_vrrpe_interface_track_url(str(rbridge_id),
                                                     interface_type,
                                                     interface_name,
                                                     str(vrrp_group_id))
        payload = PF.vrrp_track_payload(track_port, str(priority))

        print("\tURL: " + url)
        print("\tPayload: " + str(payload))

        req = Request(url, payload, headers, method=http_utils.PATCH)

        response = urlopen(req)
        response.close()

    def short_path_forwarding(self, rbridge_id, ve_interface, vrrp_group_id,
                              protocol, enable=True):
        '''
           Note: For VRRP-E only
        '''
        print("Enable/Disable short path forwarding: " + enable)

        if protocol not in PROTOCOL_VRRP_EXTENDED:
            raise ValueError("This configuration supported for VRRP-E only")

        interface_details = str(ve_interface).split(sep=" ")
        interface_type = interface_details[0]
        interface_name = interface_details[1]
        headers = http_utils.http_post_request_headers()

        url = self.get_vrrp_interface_url(
            rbridge_id, interface_type, interface_name)
        url += "/vrrp-extended-group/" + str(vrrp_group_id)
        if enable == "true":
            payload = PF.vrrp_shortpath_fwd_payload()

            print("\tURL: " + url)
            print("\tPayload: " + str(payload))

            req = Request(url, payload, headers, method=http_utils.PATCH)
        else:
            url += "/short-path-forwarding"

            print("\tURL: " + url)

            req = Request(url, None, headers, method=http_utils.DELETE)

        response = urlopen(req)
        response.close()

    def get_vrrp_interface_url(self, rbridge_id, interface_type,
                               interface_name):
        url = self._connector.get_config_url()
        if interface_type.lower() == 've':
            url += "/rbridge-id/" + str(rbridge_id)

        url += "/interface/" + interface_type + \
            "/\"" + str(interface_name) + "\""
        return url

    def get_vrrp_protocol_enable_url(self, rbridge_id):
        url = self._connector.get_config_url(self._config_type)
        url += "/rbridge-id/" + str(rbridge_id) + "/protocol"
        return url

    def get_vrrp_trackport_priority_url(self, rbridge_id, interface_type,
                                        interface_name, vrrp_group_id,
                                        track_interface_type,
                                        track_interface_name
                                        ):

        url = self._connector.get_config_url(self._config_type)
        if interface_type.lower() == 've':
            url += "/rbridge-id/" + str(rbridge_id)
        url += "/interface/" + interface_type + "/\"" + interface_name + "\"/vrrp-group/" + \
            str(vrrp_group_id) + "%2C2/track/interface/" + \
            track_interface_type + "/\"" + track_interface_name + "\""
        return url.lower()

    def get_vrrpe_trackport_priority_url(self, rbridge_id, interface_type,
                                         interface_name,
                                         vrrp_group_id,
                                         track_interface_type,
                                         track_interface_name):
        url = self._connector.get_config_url(self._config_type)
        url += "/rbridge-id/" + str(rbridge_id)
        url += "/interface/" + interface_type + "/\"" + interface_name + "\"/vrrp-extended-group/" + \
            str(vrrp_group_id) + "/track/interface/" + \
            track_interface_type + "/\"" + track_interface_name + "\""
        return url.lower()

    def get_vrrp_interface_track_url(self, rbridge_id, interface_type,
                                     interface_name, vrrp_group_id):
        # rest/config/running/interface/TenGigabitEthernet/"134/0/4"/vrrp-group/1,2/track
        url = self._connector.get_config_url(self._config_type)
        if interface_type.lower() == 've':
            url += "/rbridge-id/" + str(rbridge_id)
        url += "/interface/" + interface_type + "/\"" + interface_name + \
            "\"/vrrp-group/" + str(vrrp_group_id) + "%2C2/track"
        return url.lower()

    def get_vrrpe_interface_track_url(self, rbridge_id, interface_type,
                                      interface_name, vrrp_group_id):
        url = self._connector.get_config_url(self._config_type)
        url += "/rbridge-id/" + str(rbridge_id) + "/interface/" + interface_type + \
            "/" + str(interface_name) + "/vrrp-extended-group/" + \
            str(vrrp_group_id) + "/track"
        return url.lower()

    def delete_interface_ipaddress(self, rbridge_id, interface_type,
                                   interface_name):
        print("delete_interface_ipaddress called")
        url = self.get_vrrp_interface_url(
            rbridge_id, interface_type, interface_name)
        url += "/ip/address"
        headers = http_utils.http_post_request_headers()
        req = Request(url, None, headers, method=http_utils.DELETE)
        response = urlopen(req)
        response.close()
