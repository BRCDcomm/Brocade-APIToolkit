# Copyright (c) 2014, Brocade Communications Systems, Inc.
#
# All rights reserved.
#
# This software is licensed under the following BSD-license,
# you may not use this file unless in compliance with the
# license below:
#
# Redistribution and use in source and binary forms, with or
# without modification, are permitted provided that the
# following conditions are met:
#
# 1. Redistributions of source code must retain the above
#    copyright notice, this list of conditions and the
#    following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
# THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
# THE POSSIBILITY OF SUCH DAMAGE.


from http import client
from urllib import parse
from urllib.request import Request, urlopen

from utilities import http_utils
from scripts import payload as PF
from scripts.inventory import DeviceInventory


TYPE_PORT_CHANNEL = "Port-channel"


class VlagConfig:
    '''
    '''

    def __init__(self, connector):
        self._connector = connector

    def create_port_channel(self, name, data=None):
        ''' Create a new port channel with given name
            Optional XML Data string for the port-channel can be provided
            to create the new Port-Channel.
        '''
        assert name != None, "Port Channel name can't be None"

        # Create Request header dictionary
        headers = http_utils.http_post_request_headers()

        #build URL to create a new vlan
        url = self._connector.get_top_level_url()
        url += "/config/running/interface/"

        # build payload
        if data == None:
            encoded_payload = PF.create_port_channel_payload(name)
        else:
            encoded_payload = data.encode()

        # build request object with URL and headers
        req = Request(url, encoded_payload, headers, method="POST")

        response = urlopen(req)
        response.close()

        if response.getcode() != client.CREATED:
            raise Exception("Failed to create Port-Channel" + name)

    def delete_port_channel(self, name=''):
        '''Remove a Port-Channel
        '''
        assert name != '', "Empty Port-Channel name is not allowed"

        # Create Request header dictionary
        headers = http_utils.http_post_request_headers()

        #build URL to create a new vlan
        url = self._connector.get_top_level_url()
        url += "/config/running/interface/port-channel/" + name

        # build request object with URL and headers
        req = Request(url, None, headers, method="DELETE")

        response = urlopen(req)
        response.close()

        if response.getcode() != client.NO_CONTENT:
            raise Exception("Failed to remove Port-Channel " + name)

    def has_port_channel(self, name):
        ''' Returns boolean True if the port channel exist on the device
        '''
        found = False

        try:
            di = DeviceInventory(self._connector)
            po = di.get_interface(name, TYPE_PORT_CHANNEL)
            if po != None:
                found = True

        except Exception as ex:
            print(type(ex))
            print(str(ex))

        return found

    def add_interfaces_to_port_channel(self, name,
                                       interfaces, mode,
                                       po_type="standard"):
        ''' Adds a list of one or more physical interfaces to a port channel.
            name is name of the port channel. Generally is a number in
            string format.

            mode is either passive, on, or active
            po_type is either standard or brocade. Default is standard.
        '''
        assert interfaces != [], "Empty list of interfaces is not allowed"
        assert name != None, "Port channel name can't be None"
        assert po_type != "standard" or po_type != "brocade", \
                " Port channel type should be either standard or brocade"

        if not self.has_port_channel(name):
            print(" Port-Channel " + name +
                  " not exist. Creating it before adding interfaces.")
            self.create_port_channel(name)

        # Create Request header dictionary
        headers = http_utils.http_post_request_headers()

        print("Adding ports to Port-Channel " + name + ":")
        for interface in interfaces:
            print("\tAdding port: " + interface)
            interface_details = str(interface).split(sep=" ")
            interface_type = interface_details[0]
            interface_name = interface_details[1]

            # build interface update URL
            url = self._connector.get_config_url() + "/interface/"
            url += interface_type + "/"
            url += parse.quote('"' + interface_name + '"')
            #print ("\t" + url)
            #print("\tConfiguring channel-group " + name +
            #      " on interface: " + interface)
            data = PF.interface_channel_group_payload(interface_type.lower(),
                                                                  name,
                                                                  mode,
                                                                  po_type)
            #print (data)

            req = Request(url, data, headers, method="PATCH")
            response = urlopen(req)
            response.close()

            if response.getcode() != client.NO_CONTENT:
                raise Exception("Failed to configure channel-group " +
                                name + " on interface: " + interface)

    def remove_interfaces_from_port_channel(self, name, interfaces):
        ''' Removes interfaces from Port-channel.
            name is id of the Port-channel
            interfaces a list of physical interfaces
        '''
        assert name != None, "Port-channel name can't be None"
        assert interfaces != [], "Empty list of interfaces is not allowed"

        if not self.has_port_channel(name):
            raise Exception("Port-channel " + name + " not exist!")

        # Create Request header dictionary
        headers = http_utils.http_post_request_headers()

        print("Removing ports from Port-channel " + name + ":")
        for interface in interfaces:
            print("\tRemoving Port: " + interface)
            interface_details = str(interface).split(sep=" ")
            interface_type = interface_details[0]
            interface_name = interface_details[1]

            # build interface update URL
            url = self._connector.get_config_url() + "/interface/"
            url += interface_type + "/"
            url += parse.quote('"' + interface_name.lower() + '"') + "/"
            url += PF.CHANNEL_GROUP_TAG
            #print("\t" + url)

            #print("\tRemoving channel-group " + name +
            #      " on port: " + interface)

            req = Request(url, None, headers, method="DELETE")
            response = urlopen(req)
            response.close()

            if response.getcode() != client.NO_CONTENT:
                raise Exception("Failed to remove channel-group " + name
                                + " on interface: " + interface)

if __name__ == '__main__':
    pass
