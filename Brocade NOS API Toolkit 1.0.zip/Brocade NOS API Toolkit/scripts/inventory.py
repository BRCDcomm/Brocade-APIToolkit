# Copyright (c) 2014, Brocade Communications Systems, Inc.
#
# All rights reserved.
#
# This software is licensed under the following BSD-license,
# you may not use this file unless in compliance with the
# license below:
#
# Redistribution and use in source and binary forms, with or
# without modification, are permitted provided that the
# following conditions are met:
#
# 1. Redistributions of source code must retain the above
#    copyright notice, this list of conditions and the
#    following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
# THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
# THE POSSIBILITY OF SUCH DAMAGE.


import ipaddress
from urllib import parse
from urllib.request import Request, urlopen
from xml.dom.minidom import parseString
from xml.etree import ElementTree as ET

from utilities import http_utils
from utilities import parser
from scripts import payload as PF


class DeviceInventory:
    '''
    '''

    def __init__(self, connector):
        self._connector = connector

    def get_properties(self):
        ''' Returns a dictionary of properties.
            # <TODO> On HOLD until get complete clarity on whether
            to show cluster properties or cluster node properties.
        '''

        #URI
        url = self._connector.get_top_level_url()
        url += "/operational-state/show-vcs"

        # Create Request header dictionary
        headers = http_utils.http_post_request_headers()

        # request payload data.
        data = "<show-vcs />"
        byteData = data.encode()

        req = Request(url, byteData, headers, method="POST")

        vcs_nodes = None

        try:
            response = urlopen(req)

            # read response data and decode the bytes in a string
            # and wrap into a an xml tag to build a dom
            byteData = response.read()
            response.close()

            strData = byteData.decode("utf-8")
            print (strData)

            matched_node = None

            root = ET.fromstring(strData)
            vcs_nodes = root.find("vcs-nodes")
            for vcs_node in vcs_nodes.findall(PF.VCS_NODE_INFO):
                ip_address = vcs_node.find(PF.NODE_PUBLIC_IP_ADDRESS).text
                node_ip_address = ipaddress.ip_address(ip_address)
                if (node_ip_address == self._connector.get_ip_address()):
                    matched_node = vcs_node
                    break

            return matched_node

        except Exception as ex:
            print(type(ex))
            print(str(ex))

        return vcs_nodes

    def get_interfaces(self, interface_type="TenGigabitEthernet",
                       full_details=1):
        ''' Returns a list of specified type of Ethernet port XML DOM objects
        '''
        # Create Request header dictionary
        headers = http_utils.http_get_request_headers(full_details)

        url = self._connector.get_config_url()
        url += "/interface/" + interface_type

        # build request object with URL and headers
        req = Request(url, None, headers)

        interfaceList = []

        try:
            response = urlopen(req)

            # read response data and decode the bytes in
            # a string and wrap into a an xml tag to build a dom
            data = response.read()

            strData = parser.decode_and_wrap_in_xml(data)

            response.close()

            #parse the xml downloaded
            dom = parseString(strData)

            # retrieve the first xml tag (<tag>data</tag>) that
            # the parser finds with name tagName:Vlan
            interfaceList = dom.getElementsByTagName(interface_type)

        except Exception as ex:
            print(type(ex))
            print(str(ex))

        return interfaceList

    def get_interface(self, name, interface_type="TenGigabitEthernet",
                      full_details=2):
        ''' Returns an interface complete details XML dom object.

        '''
        assert name != '', "Empty Interface name is not allowed"
        assert interface_type != '', "Empty interface type is not allowed"

        # Create Request header dictionary
        headers = http_utils.http_get_request_headers(resource_depth=2)

        # build request url
        name = '"' + name + '"'
        qname = parse.quote(name)
        url = self._connector.get_top_level_url()
        url += "/config/running/interface/" + interface_type + "/" + qname

        # build request object with URL and headers
        req = Request(url, None, headers)

        interfaceDetials = None

        try:
            response = urlopen(req)

            # read response data and decode the bytes in
            # a string and wrap into a an xml tag to build a dom
            data = response.read()
            #print(data)

            strData = parser.decode_and_wrap_in_xml(data)
            #print (strData)

            response.close()

            #parse the xml downloaded
            dom = parseString(strData)

            # retrieve the first xml tag (<tag>data</tag>) that
            # the parser finds with name tagName:Vlan
            interfaceDetials = dom.getElementsByTagName(interface_type)[0]

        except Exception as ex:
            print(type(ex))
            print(str(ex))

        return interfaceDetials

    def get_vlans(self, full_details=1):
        ''' REturns the a list of VLAN XML DOM objects
        '''
        # Create Request header dictionary
        headers = http_utils.http_get_request_headers(full_details)

        url = self._connector.get_top_level_url()
        url += "/config/running/interface/vlan"

        # build request object with URL and headers
        req = Request(url, None, headers)

        vlansList = []

        try:
            response = urlopen(req)
            #print (response)

            # read response data and decode the bytes in a string
            # and wrap into a an xml tag to build a dom
            data = response.read()
            #print(data)

            strData = parser.decode_and_wrap_in_xml(data)
            #print (strData)

            response.close()

            #Create document object with response xml.
            dom = parseString(strData)

            # retrieve the first xml tag (<tag>data</tag>) that
            # the parser finds with name tagName:Vlan
            vlansList = dom.getElementsByTagName("Vlan")

        except Exception as ex:
            print(type(ex))
            print(str(ex))

        return vlansList

    def get_vlan(self, name):
        ''' Returns the details of VLAN
        '''
        assert name != '', "Empty VLAN name is not allowed"
        ''' REturns the a list of VLAN XML DOM objects
        '''
        # Create Request header dictionary
        headers = http_utils.http_get_request_headers(resource_depth=2)
        vlan_name = parse.quote(name)
        url = self._connector.get_top_level_url()
        url += "/config/running/interface/vlan/" + vlan_name

        # build request object with URL and headers
        req = Request(url, None, headers)

        response = urlopen(req)
        #print (response)

        # read response data and decode the bytes in a string
        # and wrap into a an xml tag to build a dom
        data = response.read()
        #print(data)

        strData = parser.decode_and_wrap_in_xml(data)
        #print (strData)

        response.close()

        #Create document object with response xml.
        dom = parseString(strData)

        # retrieve the first xml tag (<tag>data</tag>) that
        # the parser finds with name tagName:Vlan

        vlanNodes = dom.getElementsByTagName('Vlan')

        vlanNode = None
        if len(vlanNodes) != 0:
            vlanNode = vlanNodes[0]

        return vlanNode


if __name__ == '__main__':
    pass
