# Copyright (c) 2014, Brocade Communications Systems, Inc.
#
# All rights reserved.
#
# This software is licensed under the following BSD-license,
# you may not use this file unless in compliance with the
# license below:
#
# Redistribution and use in source and binary forms, with or
# without modification, are permitted provided that the
# following conditions are met:
#
# 1. Redistributions of source code must retain the above
#    copyright notice, this list of conditions and the
#    following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
# THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
# THE POSSIBILITY OF SUCH DAMAGE.

from http import client
from urllib import parse
from urllib.request import Request, urlopen
from urllib.error import  URLError

from scripts import payload as PF

from utilities import http_utils

TYPE_TENGIGABITETHERNET = "TenGigabitEthernet"
TYPE_FORTYGIGABITETHERNET = "FortyGigabitEthernet"
TYPE_PORT_CHANNEL = "Port-channel"


class InterfaceConfig:
    '''
    '''

    def __init__(self, connector):
        self._connector = connector

    def shutdown_interface(self, name,
                         interface_type="TenGigabitEthernet", shutdown=True):
        '''Shut down any type of Physical/logical interface:
           TenGigabitEthernet, FortyGigabitEthernet, GigabitEthernet,
           HundredGigabitEthernet, and Port-Channel.
        '''
        assert name != '', "Empty Interface name is not allowed"
        assert interface_type != '', "Empty interface type is not allowed"
        assert type(shutdown) == type(True), "Not a valid shutdown flag"

        # Create Request header dictionary
        headers = http_utils.http_post_request_headers()

        #build URL to create a new vlan
        url = self._connector.get_config_url()
        url += "/interface/"
        url += interface_type + "/"
        url += parse.quote('"' + name + '"')

        if (shutdown == True):
            # build payload
            payload = PF.interface_shutdown_payload(interface_type)

            # build request object with URL and headers
            req = Request(url, payload, headers, method="PATCH")
        else:
            url += "/shutdown"
            req = Request(url, None, headers, method="DELETE")

        try:
            response = urlopen(req)

            # debug print response headers
            response.close()

            if response.getcode() != client.NO_CONTENT:
                raise Exception("Failed shutdown interface " + interface_type +
                                " " + name)
        except URLError as e:
            if hasattr(e, 'code'):
                if shutdown == False and e.code != client.NOT_FOUND:
                    raise e

if __name__ == '__main__':
    pass
