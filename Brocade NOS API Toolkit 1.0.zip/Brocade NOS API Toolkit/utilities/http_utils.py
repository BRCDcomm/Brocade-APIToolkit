# Copyright (c) 2014, Brocade Communications Systems, Inc.
#
# All rights reserved.
#
# This software is licensed under the following BSD-license,
# you may not use this file unless in compliance with the
# license below:
#
# Redistribution and use in source and binary forms, with or
# without modification, are permitted provided that the
# following conditions are met:
#
# 1. Redistributions of source code must retain the above
#    copyright notice, this list of conditions and the
#    following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its contributors
#    may be used to endorse or promote products derived from this software
#    without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
# THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
# THE POSSIBILITY OF SUCH DAMAGE.

import base64
import sys


# Request Header Key constants
ACCEPT_KEY = "Accept"
USER_KEY = "WSusername"
PASSWORD_KEY = "WSpassword"
CONTETNT_TYPE_KEY = "Content-Type"
USER_AGENT_KEY = "User-Agent"
ACCEPT_LANGUAGE_KEY = "Accept-Language"
ACCEPT_ENCODING_KEY = "Accept-Encoding"
ACCEPT_CHARSET_KEY = "Accept-Charset"
RESOURCE_DEPTH_KEY = "Resource-Depth"
AUTHORIZATION = "Authorization"
CONTENT_LENGTH = "Content-Length"
ORIGIN = "ORIGIN"
# Request Header value constants
USER_AGENT_HEADER = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.154 Safari/537.36'
APPLICATION_FORM_URL_ENCODED = "application/x-www-form-urlencoded"
APPLICATION_VND_CONFIGURATION_RESOURCE_XML = 'application/vnd.configuration.resource+xml'
LANGUAGE_EN_US = "en-US"
POST = "POST"
PATCH = "PATCH"
DELETE = "DELETE"
RUNNING = "running"


def http_get_request_headers(resource_depth=1):
    ''' Utility method to create and return all the http request headers
    '''
    headers = {
        RESOURCE_DEPTH_KEY: resource_depth,
        USER_AGENT_KEY: USER_AGENT_HEADER,
        ACCEPT_KEY: APPLICATION_VND_CONFIGURATION_RESOURCE_XML,
        ACCEPT_CHARSET_KEY: 'iso-8859-1,*,utf-8',
        ACCEPT_LANGUAGE_KEY: LANGUAGE_EN_US}

    return headers


def http_get_operational_state_request_headers(resource_depth=1):
    ''' Utility method to create and return all the http request headers
    '''
    headers = {
        RESOURCE_DEPTH_KEY: resource_depth,
        USER_AGENT_KEY: USER_AGENT_HEADER,
        ACCEPT_KEY: APPLICATION_VND_CONFIGURATION_RESOURCE_XML,
        ACCEPT_CHARSET_KEY: 'iso-8859-1,*,utf-8',
        ACCEPT_LANGUAGE_KEY: LANGUAGE_EN_US}

    return headers


def http_post_request_headers():
    ''' Utility method to create and return all the http request headers
    '''
    headers = {
        USER_AGENT_KEY: USER_AGENT_HEADER,
        ACCEPT_KEY: '*/*',
        ACCEPT_ENCODING_KEY: "gzip,deflate,sdch",
        CONTETNT_TYPE_KEY: APPLICATION_FORM_URL_ENCODED,
        ACCEPT_LANGUAGE_KEY: LANGUAGE_EN_US}

    return headers


if __name__ == '__main__':
    pass
